package com.sensei.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class SenseiScreen extends Screen {
    private int tab = 0;
    private static final String[] TABS = {"ЧИТ-ФУНКЦИИ", "ЛЕГИТ", "ДРУЗЬЯ", "HUD", "МАРКЕРЫ", "НАСТРОЙКИ"};
    public SenseiScreen() { super(Text.literal("Sensei Client")); }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int w = Math.min(360, this.width - 20), h = Math.min(260, this.height - 20);
        int x = (this.width-w)/2, y = (this.height-h)/2;
        ctx.fill(x,y,x+w,y+h,0xF0120B20); ctx.fill(x,y,x+w,y+3,0xFF9B4DFF);
        ctx.drawText(textRenderer,"SENSEI CLIENT",x+14,y+12,0xFFE9D5FF,false);
        ctx.drawText(textRenderer,"FABRIC 1.21.4  •  PREVIEW",x+14,y+26,0xFF67E8F9,false);
        int ty=y+46, tw=(w-24)/3;
        for(int i=0;i<TABS.length;i++) { int tx=x+12+(i%3)*(tw+2), yy=ty+(i/3)*25;
            ctx.fill(tx,yy,tx+tw,yy+21,tab==i?0xFF6030A0:0xFF241A35);
            ctx.drawCenteredTextWithShadow(textRenderer,TABS[i],tx+tw/2,yy+7,tab==i?0xFFFFFFFF:0xFFBCA7D9); }
        int by=ty+61; ctx.fill(x+12,by,x+w-12,y+h-34,0xAA211633);
        String[] lines=switch(tab) {
            case 0 -> new String[]{"Freecam — планируется","ESP — планируется","Подсветка сундуков — планируется"};
            case 1 -> new String[]{"Следы частиц — планируется","HUD брони — планируется","Zoom — планируется","Анимации — планируется"};
            case 2 -> new String[]{"Список друзей — планируется","Шляпа сенсея — планируется"};
            case 3 -> new String[]{"FPS / координаты / броня — планируется"};
            case 4 -> new String[]{"Маркеры — планируется"};
            default -> new String[]{"Цвета и профили — планируется","Меню: Right Shift"}; };
        int ly=by+10; for(String line:lines) { ctx.fill(x+20,ly+1,x+25,ly+10,0xFF67E8F9); ctx.drawText(textRenderer,line,x+32,ly,0xFFF3E8FF,false); ly+=18; }
        ctx.drawText(textRenderer,"Основа интерфейса • функции ещё не реализованы",x+12,y+h-19,0xFFB9A5D0,false);
    }
    @Override public boolean mouseClicked(double mx,double my,int button) {
        int w=Math.min(360,width-20), h=Math.min(260,height-20), x=(width-w)/2, y=(height-h)/2, ty=y+46, tw=(w-24)/3;
        if(my>=ty&&my<ty+46) { int col=(int)((mx-(x+12))/(tw+2)), row=(int)((my-ty)/25);
            if(col>=0&&col<3&&row>=0&&row<2) { int next=row*3+col; if(next<TABS.length){tab=next;return true;} } }
        return super.mouseClicked(mx,my,button);
    }
    @Override public boolean shouldPause() { return false; }
}
